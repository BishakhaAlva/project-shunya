# SUBMISSION — copy each block into the matching form field

## 1. Project summary (138 words — paste as-is)

SOL PATROL is a free, browser-based game that turns kids ages 7-12 into commanders of a space outpost on Mars (Jezero Plains) or the Moon (Shackleton Crater). Each morning, sunshine gives limited Power, and players must choose how to spend it: making air, growing food, raising radiation shields, doing science, calling home, or resting the crew, before facing the night's forecast and event. Every choice costs something else, so no strategy wins without trade-offs, just like real NASA mission planning. Players learn why shields matter against space weather, why growing food also uses air, and why messages home take about 12 minutes from Mars but only 1 second from the Moon. Live NASA DONKI space-weather data drives the radiation risk, with honestly labelled archived real events when offline, making engineering trade-offs tangible, fun and understandable for young learners.

## 2. Project details (paste as-is)

What we built: SOL PATROL is a free, no-download browser game for ages 7-12. The player is Mission Commander of an outpost and must survive 8 days: Mars = 8 sols (one sol = 24h 37m), Moon = 8 Moon Days. Destinations: Mars — Jezero Plains (Perseverance) or Moon — Shackleton Crater, South Pole. Goal: keep Air, Food, and Crew Health above zero for 8 days and earn Science Stars for rank (Brave Cadet, Outpost Explorer, Sol Patrol Commander).

How it works: Each morning, solar panels make a random 9-20 Power (less after dust). Unspent power banks only to 5. Players tap mission cards (or tap the habitat/greenhouse/dish/rover/crew directly in the animated SVG scene): Make Air (6 Power), Grow Food (5), Raise Shields (5), Do Science (4, then +2 per star), Call Earth (3), Rest & Fix (2). Every day also has a Daily Dilemma — pick ONE of two options (e.g., water the garden or make air). Both sides always have a cost, so no choice is free. At night, crew consumes -14 Air / -12 Food and one event hits: solar storm, dust, cold night, air leak, garden pests, homesick crew, meteor, rover ice, quiet night. Tonight's forecast is shown in the morning so players learn to prepare. Crew Nova and Pip speak via speech bubbles and warn when Air/Food/Health is low. The game auto-saves and restores after reload. Failure is a gentle "Rescue Mission Launched!" screen that names which meter ran out, why, and a commander's tip — learning, not punishment. Start Night stays locked until the Daily Dilemma is picked.

Benefits and impact: It directly addresses the Junior Astronaut Mission Trainer challenge by turning abstract engineering trade-offs (finite power budget, radiation shielding, food/water/oxygen coupling, communication delay) into a playable loop. It teaches three systems ideas young learners usually miss: every resource is finite, forecasts let you prepare, and systems are coupled (food costs air, shields cost power). It is free, works offline after first load (Sun data falls back to archived real events, clearly labelled, never fake-live), needs no account/email, is keyboard and screen-reader accessible, and runs on low-end school Chromebooks — designed for classrooms and homes. Two worlds double replay value and teach comparative planetary science (12 min vs 1 s comms delay, south-pole lunar ice vs Jezero, lunar -170C nights).

Tools and languages: Vanilla HTML5, CSS3 and JavaScript (zero dependencies, no build step): index.html, style.css, game.js, data.js, test.mjs (kept automated checks), assets/favicon.svg, assets/mars-outpost.jpg, assets/manifest.json. Fonts: Fredoka and Nunito (Google Fonts). API: NASA Open APIs. Testing: Node test.mjs, syntax checks, and headless-Chrome real-click playthroughs (win, loss paths, reload-restore, keyboard, Moon run).

Creativity: Forecast-prepare-consequence loop; clickable base (not just cards); Daily Dilemma (opportunity cost); talking crew; consequence-visible gauges ("Air runs out in ~2 nights"); positive rank ladder; two destinations in one engine; live real space weather driving game risk with honest archived fallback.

Factors considered: Audience 7-12 (plain language, big targets, icons+text+numbers never colour-only, gentle failure, 10-15 min sessions); trade-off integrity (no free heals, Science escalates, shields meaningful); real-data honesty (attribution in-game via the NASA Science panel); accessibility (focus handling, Escape, progressbar ARIA, reduced-motion, 44px targets); classroom fit (no PII, low bandwidth).

## 3. NASA Data (one row per entry: Link Text + full URL)

| Link Text | URL |
|---|---|
| DONKI - Space Weather Database (via NASA Open APIs) | https://api.nasa.gov |
| NASA Open APIs | https://api.nasa.gov |
| RadLab / OSDR (NASA Open Science Data Repository) | https://science.nasa.gov |
| Mars Trek / Mars Missions (Perseverance / Jezero) | https://mars.nasa.gov |

## 4. Space Agency Partner & Other Data (one row per entry)

| Link Text | URL |
|---|---|
| CSA - Food Production on the Moon and in Remote Areas | https://asc-csa.gc.ca |
| Google Fonts - Fredoka and Nunito | https://fonts.google.com |

## Still to fill before you press Submit (only you can)

1. Demo link (30s video) + Live play URL — paste into the portal fields and into README.md top lines.
2. Team story (3 lines: team name, who built what, the spark) — README.md "Team story" section. Do not invent; use true facts.
3. (Optional, boosts LIVE data) Free personal key from https://api.nasa.gov — judges can open the game with ?key=YOUR_KEY appended.
